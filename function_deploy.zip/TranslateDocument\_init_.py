import logging
import os
import io
import datetime
import json # For metadata
from urllib.parse import urlparse

# Import Azure SDK clients
from azure.core.credentials import AzureKeyCredential
from azure.ai.translation.document import DocumentTranslationClient, DocumentTranslationInput, TranslationTarget
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient, generate_blob_sas, BlobSasPermissions

# --- Configuration (Fetched from Environment Variables) ---
# These are set in Azure App Settings (via Terraform) or local.settings.json for local dev
TRANSLATOR_ENDPOINT = os.environ["TRANSLATOR_ENDPOINT"]
TRANSLATOR_API_KEY = os.environ["TRANSLATOR_API_KEY"]
TRANSLATOR_REGION = os.environ["TRANSLATOR_REGION"]
STORAGE_CONNECTION_STRING = os.environ["STORAGE_CONNECTION_STRING"]
INPUT_CONTAINER_NAME = os.environ["INPUT_CONTAINER_NAME"]
TRANSLATED_CONTAINER_NAME = os.environ["TRANSLATED_CONTAINER_NAME"]
LOG_CONTAINER_NAME = os.environ.get("LOG_CONTAINER_NAME", "log-files") # Get from env or default

# --- Main Function Logic ---

def main(myblob: BlobClient, logblob: logging.Out[str]): # Changed trigger type hint to BlobClient for metadata access
    """
    Azure Function triggered by blob creation in 'input-documents' container.

    Args:
        myblob (BlobClient): Input binding that provides a BlobClient for the triggering blob.
                             Allows access to blob properties and metadata.
        logblob (logging.Out[str]): Output binding to write logs to a blob.
    """
    
    # Get blob properties using the BlobClient input binding
    blob_properties = myblob.get_blob_properties()
    name = blob_properties.name
    size = blob_properties.size
    metadata = blob_properties.metadata # Get metadata set by the uploader (web app)

    logging.info(f"Python blob trigger function processing blob")
    logging.info(f"Name: {name}")
    logging.info(f"Size: {size} Bytes")
    logging.info(f"Metadata: {metadata}")

    log_messages = [
        f"[{datetime.datetime.utcnow().isoformat()}] Processing started.",
        f"Blob Name: {name}",
        f"Blob Size: {size} Bytes",
        f"Blob Metadata: {json.dumps(metadata)}"
    ]

    try:
        # --- Target Language Determination ---
        target_language = metadata.get('target_language') # Read from metadata (lowercase key)

        if not target_language:
            # Fallback: try extracting from filename like 'myfile_fr.txt'
            logging.warning("Target language not found in metadata. Attempting to extract from filename.")
            log_messages.append("WARN: target_language not found in metadata. Trying filename.")
            parts = os.path.splitext(name)
            base_name = parts[0]
            if '_' in base_name:
                lang_part = base_name.split('_')[-1]
                if len(lang_part) == 2 and lang_part.isalpha():
                    target_language = lang_part.lower() # Ensure lowercase
                    logging.info(f"Target language '{target_language}' extracted from filename.")
                    log_messages.append(f"Target language inferred from filename: {target_language}")
        
        if not target_language:
            # Default if still not found
            target_language = "fr" # Default language (lowercase)
            logging.warning(f"Could not determine target language. Defaulting to '{target_language}'.")
            log_messages.append(f"WARN: Could not determine target language. Using default: {target_language}")
        else:
            target_language = target_language.lower() # Ensure lowercase from metadata
            logging.info(f"Target language for translation: {target_language}")
            log_messages.append(f"Target language determined: {target_language}")

        # --- Initialize Clients ---
        translator_credential = AzureKeyCredential(TRANSLATOR_API_KEY)
        document_translation_client = DocumentTranslationClient(TRANSLATOR_ENDPOINT, translator_credential)
        blob_service_client = BlobServiceClient.from_connection_string(STORAGE_CONNECTION_STRING)

        # --- Prepare Source and Target Containers using SAS URLs ---
        source_container_client = blob_service_client.get_container_client(INPUT_CONTAINER_NAME)
        source_container_sas_url = generate_container_sas_url(source_container_client, read=True, list_perms=True)
        logging.info(f"Generated SAS URL for source container: {INPUT_CONTAINER_NAME}")

        target_container_client = blob_service_client.get_container_client(TRANSLATED_CONTAINER_NAME)
        target_container_sas_url = generate_container_sas_url(target_container_client, read=True, write=True, delete=False, list_perms=True, create=True)
        logging.info(f"Generated SAS URL for target container: {TRANSLATED_CONTAINER_NAME}")
        log_messages.append("Generated SAS URLs for source and target containers.")

        # --- Start Translation ---
        logging.info(f"Submitting translation job for blob: {name} to language: {target_language}")
        log_messages.append(f"Submitting translation job to language: {target_language}")

        translation_inputs = [
            DocumentTranslationInput(
                source_url=source_container_sas_url, 
                targets=[
                    TranslationTarget(
                        target_url=target_container_sas_url, 
                        language_code=target_language
                    )
                ],
                filter={'prefix': name} # Use prefix filter to target the specific blob
            )
        ]

        poller = document_translation_client.begin_translation(inputs=translation_inputs)

        logging.info(f"Translation job submitted. Poller ID: {poller.id}")
        log_messages.append(f"Translation job submitted. Poller ID: {poller.id}")

        # --- Wait for Completion ---
        result = poller.result() # Blocks until finished

        log_messages.append(f"Poller final status: {poller.status()}")
        logging.info(f"Translation job finished with status: {poller.status()}")

        # --- Process Results ---
        docs_succeeded = 0
        docs_failed = 0

        for document in result:
            if document.status == "Succeeded":
                docs_succeeded += 1
                logging.info(f"  Document ID: {document.id} Succeeded")
                log_messages.append(f"  SUCCESS: Source: {document.source_document_url}, Target: {document.translated_document_url}")
            else:
                docs_failed += 1
                logging.error(f"  Document ID: {document.id} Failed - Error: {document.error.code}, Message: {document.error.message}")
                log_messages.append(f"  FAILURE: Source: {document.source_document_url}, Error: {document.error.code} - {document.error.message}")

        overall_status = f"Translation job {poller.id} finished. Succeeded: {docs_succeeded}, Failed: {docs_failed}. Status: {poller.status()}"
        log_messages.append(overall_status)
        logging.info(overall_status)

    except Exception as e:
        error_message = f"An error occurred during translation processing for blob {name}: {e}"
        logging.error(error_message, exc_info=True)
        log_messages.append(f"ERROR: {error_message}")

    finally:
        # --- Write Logs ---
        log_content = "\n".join(log_messages)
        logblob.set(log_content)
        logging.info(f"Log messages written to log blob for {name}.")

# --- Helper Functions ---

def generate_container_sas_url(container_client: ContainerClient, read=False, write=False, delete=False, list_perms=False, create=False) -> str:
    """Generates a SAS URL for a container with specified permissions."""
    try:
        sas_token = generate_blob_sas(
            account_name=container_client.account_name,
            container_name=container_client.container_name,
            account_key=container_client.credential.account_key,
            permission=BlobSasPermissions(read=read, write=write, delete=delete, list=list_perms, create=create),
            expiry=datetime.datetime.utcnow() + datetime.timedelta(hours=1)
        )
        container_sas_url = f"{container_client.url}?{sas_token}"
        return container_sas_url
    except AttributeError as e:
        logging.error(f"Failed to generate SAS token. Check storage credential type: {e}")
        raise ValueError("Could not generate SAS token, ensure connection string provides account key.") from e
    except Exception as e:
        logging.error(f"An unexpected error occurred generating container SAS URL: {e}")
        raise
