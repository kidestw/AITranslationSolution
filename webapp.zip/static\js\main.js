// Add custom JS if needed
console.log("Nedamco Translator frontend loaded.");
